pixproof
========

WordPress photo gallery proofing plugin. Using special protected galleries you will allow your clients to examine and approve your photos.
